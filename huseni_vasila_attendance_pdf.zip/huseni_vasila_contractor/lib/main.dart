import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const HuseniVasilaApp());

class Worker {
  final String id, name, role;
  final int rate;
  const Worker(this.id, this.name, this.role, this.rate);
}

enum AttendanceStatus { present, absent, half }

class HuseniVasilaApp extends StatefulWidget {
  const HuseniVasilaApp({super.key});
  @override State<HuseniVasilaApp> createState() => _AppState();
}

class _AppState extends State<HuseniVasilaApp> {
  ThemeMode mode = ThemeMode.light;
  String lang = 'हिंदी';
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Huseni Vasila Contractor',
    themeMode: mode,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.amber, scaffoldBackgroundColor: const Color(0xfff6f6f4)),
    darkTheme: ThemeData.dark(useMaterial3: true).copyWith(colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber, brightness: Brightness.dark)),
    home: HomeShell(lang: lang, onLanguage: (v) => setState(() => lang=v), onTheme: () => setState(() => mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark)),
  );
}

class HomeShell extends StatefulWidget {
  final String lang; final ValueChanged<String> onLanguage; final VoidCallback onTheme;
  const HomeShell({super.key, required this.lang, required this.onLanguage, required this.onTheme});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index=0;
  final pages = const [DashboardPage(), ProjectsPage(), WorkersPage(), PaymentsPage(), MorePage()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Huseni Vasila Contractor', style: TextStyle(fontWeight: FontWeight.w800)), actions:[IconButton(onPressed: widget.onTheme, icon: const Icon(Icons.dark_mode_outlined))]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex:index, onDestinationSelected:(i)=>setState(()=>index=i), destinations: const [
      NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Dashboard'),
      NavigationDestination(icon:Icon(Icons.apartment_outlined),selectedIcon:Icon(Icons.apartment),label:'Projects'),
      NavigationDestination(icon:Icon(Icons.groups_outlined),selectedIcon:Icon(Icons.groups),label:'Workers'),
      NavigationDestination(icon:Icon(Icons.payments_outlined),selectedIcon:Icon(Icons.payments),label:'Payments'),
      NavigationDestination(icon:Icon(Icons.more_horiz),label:'More'),
    ]),
  );
}

class DashboardPage extends StatelessWidget { const DashboardPage({super.key});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  Card(color:Colors.amber.shade400, child: const Padding(padding:EdgeInsets.all(18),child:Row(children:[CircleAvatar(radius:28,child:Icon(Icons.person)),SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('स्वागत है!',style:TextStyle(fontWeight:FontWeight.bold)),Text('Huseni Vasila',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),Text('Contractor')]))]))),
  const SizedBox(height:12),
  Card(child: ListTile(leading: const Icon(Icons.fact_check, size: 34), title: const Text('मजदूर Attendance', style: TextStyle(fontWeight: FontWeight.w900)), subtitle: const Text('हर दिन की हाजिरी और महीने की PDF रिपोर्ट'), trailing: const Icon(Icons.chevron_right), onTap: ()=>Navigator.push(c, MaterialPageRoute(builder: (_)=>const AttendancePage())))),
  const SizedBox(height:12), const Text('Quick Overview',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)), const SizedBox(height:8),
  GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.7,children:[
   stat('कुल आमदनी','₹3,80,000',Icons.trending_up,Colors.green),stat('कुल खर्च','₹1,35,000',Icons.trending_down,Colors.red),stat('Running Projects','5',Icons.apartment,Colors.blue),stat('Total Workers','28',Icons.groups,Colors.deepPurple),
  ]), const SizedBox(height:18),
  const Text('Recent Projects',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)), const SizedBox(height:8),
  projectCard('Dream Home','Ajmer, Rajasthan',60), projectCard('Shree Ram Villa','Kishangarh, Rajasthan',35),
 ]);
}
Widget stat(String a,String b,IconData i,Color col)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[Icon(i,color:col),const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(b,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),Text(a,style:const TextStyle(fontSize:12))]))])));
Widget projectCard(String name,String place,int p)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Icon(Icons.home_work_outlined),const SizedBox(width:10),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16))),Text('$p%')]),Text(place),const SizedBox(height:8),LinearProgressIndicator(value:p/100),])));

class ProjectsPage extends StatelessWidget { const ProjectsPage({super.key}); @override Widget build(BuildContext c)=>SimpleList(title:'Projects', icon:Icons.apartment, items:const ['Dream Home • 60% • In Progress','Shree Ram Villa • 35% • In Progress','Green Residency • 20% • On Hold','City Center • 100% • Completed'], add:'नया Project जोड़ें'); }
class WorkersPage extends StatelessWidget { const WorkersPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(body:ListView(padding:const EdgeInsets.all(16),children:[
  Row(children:[const Icon(Icons.groups),const SizedBox(width:8),const Text('Workers / Mistri',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900))]),
  const SizedBox(height:12),
  FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const AttendancePage())),icon:const Icon(Icons.fact_check),label:const Text('Attendance खोलें')),
  const SizedBox(height:8),
  ...const [Worker('1','Ramesh Kumar','Raj Mistri',800),Worker('2','Shabbir Ali','Helper',600),Worker('3','Mahesh Prajapat','Raj Mistri',900),Worker('4','Imran Khan','Helper',600),Worker('5','Suresh Yadav','Mistri',800)].map((w)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.groups)),title:Text('${w.name} • ${w.role} • ₹${w.rate}/day',style:const TextStyle(fontWeight:FontWeight.w600)),trailing:const Icon(Icons.chevron_right))))),
  const SizedBox(height:8),FilledButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('नया मजदूर जोड़ें'),content:const Text('अगले अपडेट में नाम, काम और रेट भरकर Save किया जा सकेगा.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('बंद करें'))])),icon:const Icon(Icons.add),label:const Text('नया मजदूर जोड़ें'))
])); }
class PaymentsPage extends StatelessWidget { const PaymentsPage({super.key}); @override Widget build(BuildContext c)=>SimpleList(title:'Payments',icon:Icons.payments,items:const ['Mr. Suresh Sharma • ₹1,50,000 • Paid','Mr. Ajay Singh • ₹80,000 • Pending','Ramesh Kumar • ₹8,000 • Worker Salary','Shabbir Ali • ₹6,000 • Worker Salary'],add:'नया Payment जोड़ें'); }
class SimpleList extends StatelessWidget { final String title,add; final IconData icon; final List<String> items; const SimpleList({super.key,required this.title,required this.icon,required this.items,required this.add}); @override Widget build(BuildContext c)=>Scaffold(body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Icon(icon),const SizedBox(width:8),Text(title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))]),const SizedBox(height:12),...items.map((x)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(x,style:const TextStyle(fontWeight:FontWeight.w600)),trailing:const Icon(Icons.chevron_right)))),const SizedBox(height:8),FilledButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:Text(add),content:const Text('यहाँ नया रिकॉर्ड जोड़ने का फॉर्म खुलेगा।'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('बंद करें'))])),icon:const Icon(Icons.add),label:Text(add))])); }

class AttendancePage extends StatefulWidget { const AttendancePage({super.key}); @override State<AttendancePage> createState()=>_AttendancePageState(); }
class _AttendancePageState extends State<AttendancePage> {
  final workers = const [Worker('1','Ramesh Kumar','Raj Mistri',800),Worker('2','Shabbir Ali','Helper',600),Worker('3','Mahesh Prajapat','Raj Mistri',900),Worker('4','Imran Khan','Helper',600),Worker('5','Suresh Yadav','Mistri',800)];
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  final Map<String, AttendanceStatus> records = {};
  bool loading = true;

  @override void initState(){super.initState(); _load();}
  String key(String worker, DateTime day)=>'$worker-${DateFormat('yyyy-MM-dd').format(day)}';
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); for(final w in workers){ for(int d=1; d<=DateTime(month.year,month.month+1,0).day;d++){ final v=p.getString(key(w.id,DateTime(month.year,month.month,d))); if(v!=null) records[key(w.id,DateTime(month.year,month.month,d))]=AttendanceStatus.values.firstWhere((e)=>e.name==v); }} setState(()=>loading=false); }
  Future<void> _save(String k, AttendanceStatus s) async { records[k]=s; final p=await SharedPreferences.getInstance(); await p.setString(k,s.name); setState((){}); }
  AttendanceStatus? status(String w,int d)=>records[key(w,DateTime(month.year,month.month,d))];
  int daysInMonth()=>DateTime(month.year,month.month+1,0).day;
  String monthName()=>DateFormat('MMMM yyyy').format(month);

  @override Widget build(BuildContext context){
    final days=daysInMonth();
    return Scaffold(appBar:AppBar(title:const Text('मजदूर Attendance')),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(12),children:[
      Card(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[IconButton(onPressed:()=>setState(()=>month=DateTime(month.year,month.month-1)),icon:const Icon(Icons.chevron_left)),Expanded(child:Center(child:Text(monthName(),style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)))),IconButton(onPressed:()=>setState(()=>month=DateTime(month.year,month.month+1)),icon:const Icon(Icons.chevron_right))]))),
      Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_legend(Colors.green,'P = Present'),_legend(Colors.red,'A = Absent'),_legend(Colors.orange,'H = Half Day')]))),
      const SizedBox(height:8),
      Card(child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(columnSpacing:10,headingRowHeight:48,dataRowMinHeight:54,dataRowMaxHeight:66,columns:[const DataColumn(label:Text('Worker',style:TextStyle(fontWeight:FontWeight.w900))),...List.generate(days,(i)=>DataColumn(label:Text('${i+1}',style:const TextStyle(fontWeight:FontWeight.w800))))],rows:workers.map((w)=>DataRow(cells:[DataCell(SizedBox(width:125,child:Text(w.name,style:const TextStyle(fontWeight:FontWeight.w700)))),...List.generate(days,(i){final d=i+1;final s=status(w.id,d);return DataCell(GestureDetector(onTap:()=>_cycle(w,d),child:Container(width:28,height:28,alignment:Alignment.center,decoration:BoxDecoration(shape:BoxShape.circle,color:s==AttendanceStatus.present?Colors.green.shade200:s==AttendanceStatus.absent?Colors.red.shade200:s==AttendanceStatus.half?Colors.orange.shade200:Colors.grey.shade200),child:Text(s==AttendanceStatus.present?'P':s==AttendanceStatus.absent?'A':s==AttendanceStatus.half?'H':'-',style:const TextStyle(fontWeight:FontWeight.w900))))));})])))),
      const SizedBox(height:12),
      ...workers.map((w)=>_summaryCard(w,days)),
      const SizedBox(height:8),
      FilledButton.icon(onPressed:()=>_makePdf(),icon:const Icon(Icons.picture_as_pdf),label:const Padding(padding:EdgeInsets.symmetric(vertical:13),child:Text('इस महीने की Attendance PDF निकालें'))),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:()=>_makePdf(lastMonth:true),icon:const Icon(Icons.history),label:const Text('पिछले महीने की पूरी PDF रिपोर्ट')),
      const SizedBox(height:18),
      const Text('कैसे भरें?',style:TextStyle(fontWeight:FontWeight.w900,fontSize:17)),
      const Text('हर दिन के बॉक्स पर बार-बार दबाएँ: P = Present → H = Half Day → A = Absent → खाली।'),
    ]));
  }
  Widget _legend(Color c,String t)=>Row(children:[Container(width:16,height:16,decoration:BoxDecoration(color:c,shape:BoxShape.circle)),const SizedBox(width:5),Text(t,style:const TextStyle(fontSize:11))]);
  void _cycle(Worker w,int d){final k=key(w.id,DateTime(month.year,month.month,d));final old=records[k];final next=old==null?AttendanceStatus.present:old==AttendanceStatus.present?AttendanceStatus.half:old==AttendanceStatus.half?AttendanceStatus.absent:AttendanceStatus.present;_save(k,next);}
  Widget _summaryCard(Worker w,int days){int p=0,a=0,h=0;for(int d=1;d<=days;d++){final s=status(w.id,d);if(s==AttendanceStatus.present)p++;if(s==AttendanceStatus.absent)a++;if(s==AttendanceStatus.half)h++;}final total=p*w.rate+h*(w.rate/2);return Card(child:ListTile(title:Text('${w.name} • ₹${w.rate}/day',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('Present: $p   Half: $h   Absent: $a'),trailing:Text('₹${total.toStringAsFixed(0)}',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16))));}

  Future<void> _makePdf({bool lastMonth=false}) async {
    final m=lastMonth?DateTime(month.year,month.month-1):month;final days=DateTime(m.year,m.month+1,0).day;final doc=pw.Document();
    final prefs=await SharedPreferences.getInstance();
    final saved= <String, AttendanceStatus>{};
    for(final w in workers){ for(int d=1;d<=days;d++){ final dt=DateTime(m.year,m.month,d); final v=prefs.getString(key(w.id,dt)); if(v!=null){ saved[key(w.id,dt)]=AttendanceStatus.values.firstWhere((e)=>e.name==v); } } }
    doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4,build:(ctx)=>[
      pw.Text('Huseni Vasila Contractor',style:pw.TextStyle(fontSize:20,fontWeight:pw.FontWeight.bold)),
      pw.SizedBox(height:5),pw.Text('Worker Attendance Report - ${DateFormat('MMMM yyyy').format(m)}'),pw.SizedBox(height:14),
      pw.Table.fromTextArray(headers:['Worker','Role','Present','Half Day','Absent','Payable'],data:workers.map((w){int p=0,a=0,h=0;for(int d=1;d<=days;d++){final s=saved[key(w.id,DateTime(m.year,m.month,d))];if(s==AttendanceStatus.present)p++;if(s==AttendanceStatus.absent)a++;if(s==AttendanceStatus.half)h++;}final total=p*w.rate+h*(w.rate/2);return [w.name,w.role,p.toString(),h.toString(),a.toString(),'Rs ${total.toStringAsFixed(0)}'];}).toList()),
      pw.SizedBox(height:18),pw.Text('P = Present | H = Half Day | A = Absent'),
      pw.SizedBox(height:8),pw.Text('Report generated: ${DateFormat('dd-MM-yyyy HH:mm').format(DateTime.now())}'),
    ]));
    await Printing.sharePdf(bytes:Uint8List.fromList(await doc.save()),filename:'attendance_${DateFormat('yyyy_MM').format(m)}.pdf');
  }
}

class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
 const Text('More',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:10),
 const ListTile(leading:Icon(Icons.inventory_2_outlined),title:Text('Materials'),subtitle:Text('Cement, sand, bricks, steel, tiles')),
 const ListTile(leading:Icon(Icons.receipt_long_outlined),title:Text('Bill / Estimate'),subtitle:Text('Estimate और professional bill बनाएं')),
 const ListTile(leading:Icon(Icons.bar_chart_outlined),title:Text('Reports'),subtitle:Text('Income, expense और profit reports')),
 const ListTile(leading:Icon(Icons.person_outline),title:Text('Clients'),subtitle:Text('Client details, site, payment और progress')),
 const ListTile(leading:Icon(Icons.camera_alt_outlined),title:Text('Site Photos / Videos'),subtitle:Text('काम की progress रिकॉर्ड करें')),
 const ListTile(leading:Icon(Icons.phone_outlined),title:Text('Call / WhatsApp'),subtitle:Text('Client से जल्दी संपर्क करें')),
 const Divider(),
 const ListTile(leading:Icon(Icons.language),title:Text('Language'),subtitle:Text('हिंदी • English • ગુજરાતી')),
 const ListTile(leading:Icon(Icons.cloud_outlined),title:Text('Cloud Backup'),subtitle:Text('डेटा का backup सुरक्षित रखें')),
 const ListTile(leading:Icon(Icons.notifications_active_outlined),title:Text('Payment Reminder'),subtitle:Text('बकाया payment की याद दिलाएं')),
 const ListTile(leading:Icon(Icons.lock_outline),title:Text('OTP Login'),subtitle:Text('सुरक्षित login')),
 ]); }
