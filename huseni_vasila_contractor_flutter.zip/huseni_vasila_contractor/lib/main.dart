import 'package:flutter/material.dart';

void main() => runApp(const HuseniVasilaApp());

class HuseniVasilaApp extends StatefulWidget {
  const HuseniVasilaApp({super.key});
  @override State<HuseniVasilaApp> createState() => _AppState();
}

class _AppState extends State<HuseniVasilaApp> {
  ThemeMode mode = ThemeMode.light;
  String lang = 'हिंदी';
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Huseni Vasila Contractor',
    themeMode: mode,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.amber, scaffoldBackgroundColor: const Color(0xfff6f6f4)),
    darkTheme: ThemeData.dark(useMaterial3: true).copyWith(colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber, brightness: Brightness.dark)),
    home: HomeShell(lang: lang, onLanguage: (v) => setState(() => lang=v), onTheme: () => setState(() => mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark)),
  );
}

class HomeShell extends StatefulWidget {
  final String lang; final ValueChanged<String> onLanguage; final VoidCallback onTheme;
  const HomeShell({super.key, required this.lang, required this.onLanguage, required this.onTheme});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index=0;
  final pages = const [DashboardPage(), ProjectsPage(), WorkersPage(), PaymentsPage(), MorePage()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Huseni Vasila Contractor', style: TextStyle(fontWeight: FontWeight.w800)), actions:[IconButton(onPressed: widget.onTheme, icon: const Icon(Icons.dark_mode_outlined))]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex:index, onDestinationSelected:(i)=>setState(()=>index=i), destinations: const [
      NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Dashboard'),
      NavigationDestination(icon:Icon(Icons.apartment_outlined),selectedIcon:Icon(Icons.apartment),label:'Projects'),
      NavigationDestination(icon:Icon(Icons.groups_outlined),selectedIcon:Icon(Icons.groups),label:'Workers'),
      NavigationDestination(icon:Icon(Icons.payments_outlined),selectedIcon:Icon(Icons.payments),label:'Payments'),
      NavigationDestination(icon:Icon(Icons.more_horiz),label:'More'),
    ]),
  );
}

class DashboardPage extends StatelessWidget { const DashboardPage({super.key});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  Card(color:Colors.amber.shade400, child: const Padding(padding:EdgeInsets.all(18),child:Row(children:[CircleAvatar(radius:28,child:Icon(Icons.person)),SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('स्वागत है!',style:TextStyle(fontWeight:FontWeight.bold)),Text('Huseni Vasila',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),Text('Contractor')]))]))),
  const SizedBox(height:12), const Text('Quick Overview',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)), const SizedBox(height:8),
  GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.7,children:[
   stat('कुल आमदनी','₹3,80,000',Icons.trending_up,Colors.green),stat('कुल खर्च','₹1,35,000',Icons.trending_down,Colors.red),stat('Running Projects','5',Icons.apartment,Colors.blue),stat('Total Workers','28',Icons.groups,Colors.deepPurple),
  ]), const SizedBox(height:18),
  const Text('Recent Projects',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)), const SizedBox(height:8),
  projectCard('Dream Home','Ajmer, Rajasthan',60), projectCard('Shree Ram Villa','Kishangarh, Rajasthan',35),
 ]);
}
Widget stat(String a,String b,IconData i,Color col)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[Icon(i,color:col),const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(b,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),Text(a,style:const TextStyle(fontSize:12))]))])));
Widget projectCard(String name,String place,int p)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Icon(Icons.home_work_outlined),const SizedBox(width:10),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16))),Text('$p%')]),Text(place),const SizedBox(height:8),LinearProgressIndicator(value:p/100),])));

class ProjectsPage extends StatelessWidget { const ProjectsPage({super.key}); @override Widget build(BuildContext c)=>SimpleList(title:'Projects', icon:Icons.apartment, items:const ['Dream Home • 60% • In Progress','Shree Ram Villa • 35% • In Progress','Green Residency • 20% • On Hold','City Center • 100% • Completed'], add:'नया Project जोड़ें'); }
class WorkersPage extends StatelessWidget { const WorkersPage({super.key}); @override Widget build(BuildContext c)=>SimpleList(title:'Workers / Mistri',icon:Icons.groups,items:const ['Ramesh Kumar • Raj Mistri • ₹800/day','Shabbir Ali • Helper • ₹600/day','Mahesh Prajapat • Raj Mistri • ₹900/day','Imran Khan • Helper • ₹600/day','Suresh Yadav • Mistri • ₹800/day'],add:'नया मजदूर जोड़ें'); }
class PaymentsPage extends StatelessWidget { const PaymentsPage({super.key}); @override Widget build(BuildContext c)=>SimpleList(title:'Payments',icon:Icons.payments,items:const ['Mr. Suresh Sharma • ₹1,50,000 • Paid','Mr. Ajay Singh • ₹80,000 • Pending','Ramesh Kumar • ₹8,000 • Worker Salary','Shabbir Ali • ₹6,000 • Worker Salary'],add:'नया Payment जोड़ें'); }
class SimpleList extends StatelessWidget { final String title,add; final IconData icon; final List<String> items; const SimpleList({super.key,required this.title,required this.icon,required this.items,required this.add}); @override Widget build(BuildContext c)=>Scaffold(body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Icon(icon),const SizedBox(width:8),Text(title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))]),const SizedBox(height:12),...items.map((x)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(x,style:const TextStyle(fontWeight:FontWeight.w600)),trailing:const Icon(Icons.chevron_right)))),const SizedBox(height:8),FilledButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:Text(add),content:const Text('यहाँ नया रिकॉर्ड जोड़ने का फॉर्म खुलेगा।'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('बंद करें'))])),icon:const Icon(Icons.add),label:Text(add))])); }

class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
 const Text('More',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:10),
 const ListTile(leading:Icon(Icons.inventory_2_outlined),title:Text('Materials'),subtitle:Text('Cement, sand, bricks, steel, tiles')),
 const ListTile(leading:Icon(Icons.receipt_long_outlined),title:Text('Bill / Estimate'),subtitle:Text('Estimate और professional bill बनाएं')),
 const ListTile(leading:Icon(Icons.bar_chart_outlined),title:Text('Reports'),subtitle:Text('Income, expense और profit reports')),
 const ListTile(leading:Icon(Icons.person_outline),title:Text('Clients'),subtitle:Text('Client details, site, payment और progress')),
 const ListTile(leading:Icon(Icons.camera_alt_outlined),title:Text('Site Photos / Videos'),subtitle:Text('काम की progress रिकॉर्ड करें')),
 const ListTile(leading:Icon(Icons.phone_outlined),title:Text('Call / WhatsApp'),subtitle:Text('Client से जल्दी संपर्क करें')),
 const Divider(),
 const ListTile(leading:Icon(Icons.language),title:Text('Language'),subtitle:Text('हिंदी • English • ગુજરાતી')),
 const ListTile(leading:Icon(Icons.cloud_outlined),title:Text('Cloud Backup'),subtitle:Text('डेटा का backup सुरक्षित रखें')),
 const ListTile(leading:Icon(Icons.notifications_active_outlined),title:Text('Payment Reminder'),subtitle:Text('बकाया payment की याद दिलाएं')),
 const ListTile(leading:Icon(Icons.lock_outline),title:Text('OTP Login'),subtitle:Text('सुरक्षित login')),
 ]); }
